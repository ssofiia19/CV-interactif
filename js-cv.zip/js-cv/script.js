//Variables qui //
let saisi = prompt("Do you like cats? Pleas answer 'yes' or 'no'.")
let result = saisi =="yes" ? alert ("You are allow to visit this page. Click'ok' to continue"): alert("You are not allow to visit this page. Please, close this window.")


function changeCat() { // Fonction pour changer l'image //
  document.getElementById('myimage').src = "image/cat2.jpg";
}
function changeCat2() {
  document.getElementById('myimage').src = "image/funny.jpg";
}

  function myFunction() {  //Fonction qui permet de mettre à jour l'information du cv une fois l'utilisateur clique sur le bouton//
    document.getElementById("name").innerHTML = "Your Meow Name:)";
    document.getElementsByClassName("el2")[0].innerHTML = "Your Job";
    document.getElementById("info").innerHTML = "Your information: Meow meow….Meow!! meowww. Meow meowmeowMeow meowmeo, Meow meow….Meow!! meowww. Meow meowmeowMeow meowmeow Meow meow….Meow!! meowww. Meow meowmeowMeow meowmeow Meow meow….Meow!! meowww. Meow meowmeowMeow meowmeow meowww. Meow meowmeowMeow meowmeo, Meow meow….Meow";
    document.getElementsByClassName("contact")[0].innerHTML = "Your telephone number";
    document.getElementsByClassName("contact")[1].innerHTML = "Your mail";
    document.getElementsByClassName("contact")[2].innerHTML = "Your position";
    document.getElementsByClassName("cmp")[0].innerHTML = "First skill";
    document.getElementsByClassName("cmp")[1].innerHTML = "Second skill";
    document.getElementsByClassName("cmp")[2].innerHTML = "Third skill";
    document.getElementsByClassName("cmp")[3].innerHTML = "Fourth skill";
    document.getElementsByClassName("cmp")[4].innerHTML = "Fifth skill";
    document.getElementsByClassName("cmp")[5].innerHTML = "Sixth skill";
    document.getElementsByClassName("exp")[0].innerHTML = "Work company";
    document.getElementsByClassName("exp")[1].innerHTML = "Work company";
    document.getElementsByClassName("exp")[2].innerHTML = "Work company";
  }


 